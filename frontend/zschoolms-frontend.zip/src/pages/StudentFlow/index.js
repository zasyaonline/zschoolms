export { default as MyProfile } from './MyProfile';
export { default as MyAttendance } from './MyAttendance';
export { default as MyMarksHistory } from './MyMarksHistory';
